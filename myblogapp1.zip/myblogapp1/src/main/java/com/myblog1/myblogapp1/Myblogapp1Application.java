package com.myblog1.myblogapp1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Myblogapp1Application {

	public static void main(String[] args) {
		SpringApplication.run(Myblogapp1Application.class, args);
	}

}
